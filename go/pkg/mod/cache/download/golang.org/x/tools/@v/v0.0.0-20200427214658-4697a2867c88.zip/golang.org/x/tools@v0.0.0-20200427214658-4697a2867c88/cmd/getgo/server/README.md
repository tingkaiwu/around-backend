# getgo server

## Deployment

```
gcloud app deploy --promote --project golang-org
```
