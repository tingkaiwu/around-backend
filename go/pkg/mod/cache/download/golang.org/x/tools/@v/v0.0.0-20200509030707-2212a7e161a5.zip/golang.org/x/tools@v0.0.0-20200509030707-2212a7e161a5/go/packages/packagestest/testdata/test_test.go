package fake1

type ATestType string //@check("ATestType","ATestType")
